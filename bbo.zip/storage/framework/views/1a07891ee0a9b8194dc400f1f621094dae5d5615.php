<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" style="margin-top:3%;">
            <div class="card">
                <center>
                    <img src="<?php echo e(url('img/logoCircle.png')); ?>" width="100" alt="logo" style="margin-bottom:20px;">
                </center>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST"  action="/forget-password">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="email">Username</label><br>
                            <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your username" required autofocus>
                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong>Invalid Email or Password</strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row mb-0" style="margin-top:5%;">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Send Password Reset Link')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DatawordsPH\Desktop\BBO\BBOHRSystem\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>