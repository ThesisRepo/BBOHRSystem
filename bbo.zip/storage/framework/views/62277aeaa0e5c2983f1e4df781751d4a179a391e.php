<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
    <dashboard-view :user="<?php echo e(auth()->user()->load('roles')->load('userInformation.department', 'assignedPrp', 'assignedFinance')); ?>"></dashboard-view>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DatawordsPH\Desktop\BBO\BBOHRSystem\resources\views/home.blade.php ENDPATH**/ ?>