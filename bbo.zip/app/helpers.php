<?php
// perform if statement before defining function to avoid conflict