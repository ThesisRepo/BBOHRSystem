<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo asset('images/bbo.ico'); ?>"/>
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet"> -->
</head>
<?php echo $__env->yieldContent('style'); ?>

<style>
.col-md-7 {
    height:100vh;
}
.col-md-7 main, .col-md-5 main {
    position: relative;
  top: 50%;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
#name {
    height:500px;
}
@media  screen and (max-width: 800px) {
    #name {
    height: 300px;
  }
}
#companyName, #appName{
    font-size:50px;
}
#companyName{
    color:#3490dc
}
.col-md-7 {
    background-color:#3490dc;
}
</style>
<?php echo $__env->yieldContent('js'); ?>
<body>
    <div id="app" class="container-fluid">
        <div class="row">
            <?php if(auth()->guard()->guest()): ?>
            <div class="col-md-5" >
                <main class="py-4" >
                    <div class="container-fluid" id="name"  >
                        <div class="row justify-content-center">
                            <div class="col-md-9" >
                                <img  src="<?php echo e(url('img/logo.png')); ?>" width="80" height="50" class="mb-5" alt="logo">
                                <p id="companyName">BLUE BEE ONE </p>
                                <p id="appName">REQUEST MANAGEMENT SYSTEM</p>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="app" class="col-md-7">
                <main class="py-4">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
            <?php endif; ?>
        </div>
        <?php if(auth()->guard()->check()): ?>
        <div id="app">
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
<!-- <div id="app">
        <?php if(auth()->guard()->guest()): ?>
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm" id="navbar">
            <div>
                  <img src="<?php echo e(url('img/logo.png')); ?>" width="100" alt="logo"  class="float-left">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                 
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <ul class="navbar-nav ml-auto">
                    </ul>
                </div>
            </div>
        </nav>
        <div>
            
        </div>
        <?php endif; ?>
        <div id="app">
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div> --><?php /**PATH C:\Users\DatawordsPH\Desktop\BBO\BBOHRSystem\resources\views/layouts/app.blade.php ENDPATH**/ ?>