<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet">
    <style>
    .form-group button{
        width:100%;
        height:40px;
    }
    .form-group button[type=submit]{
        background-color:#007bff;
        color:white;
        
    }
    .form-group button[type=button]{
        background-color:#F4F6F6 ;
        color:black;
    }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
   <script>
   </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-9" style="margin-top: 3%;">
            <div class="card" >             
                <center style="margin-top: 5%;">
                    <img src="http://localhost:8000/img/user_logo.png" width="100" alt="logo">
                </center>
                <br>
                <div class="card-body" >
                    <form method="POST"  action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group  row" >
                            <div class="col-md-10 mb-3  mx-auto" >
                                <div class="md-form form-group">
                                    <label for="email">Email</label>
                                    <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  name="email"  value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Enter your email" autofocus>
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-10 mb-3 mx-auto">
                                <div class="md-form form-group">
                                    <label for="password">Password</label>
                                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="123456789" required autocomplete="current-password" >
                                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                       
                        <div class="form-group row">
                            <div class="col-md-10  mx-auto">
                                <button type="submit">
                                   <strong>Sign In</strong> 
                                </button>
                            </div>
                        </div> 
                        <div class="form-group row">
                            <div id ="gmail" class="col-md-10 mx-auto">
                                <button type="button" onclick="window.location='<?php echo e(url("auth/google")); ?>'">
                                    <img src="http://localhost:8000/img/google_logo.png" style="float:left;margin-left:25px;width:27px;height:27px" alt="">
                                    <strong style="margin-right:25px;">Login With Google</strong>
                                </button>
                            </div>
                        </div>
                        <?php if ($errors->has('invalid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('invalid'); ?>
                            <div style="width:100%;text-align:center">
                            <span style="color:red;">
                                    <?php echo e($message); ?>

                                </span>
                            </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <div class="form-group row">
                            <div class="col-md-10  mx-auto"> 
                                <div class="form-check">    
                                    <div class="left">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember"  value = "<?php echo e(old('remember') ? 'checked' : ''); ?>">
                                        <label class="form-check-label" for="remember">
                                            Remember Me
                                        </label>
                                    </div>
                                </div>
                                <div class="right">
                                    <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link" href="/forget-password">
                                            Forgot Your Password ?
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>      
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

 <!-- <div class="row justify-content-center">
        <div class="col-md-8" style="margin-top: 3%;">
            <div class="card" >
               
                <center style="margin-top: 3%;">
                    <img src="http://localhost:8000/img/logoCircle.png" width="100" alt="logo">
                </center>
           
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php if ($errors->has('invalid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('invalid'); ?>
                            <div style="width:100%;text-align:center">
                            <span style="color:red;">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            </div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <div class="col-md-10 mb-3 col-3 mx-auto">
                                <div class="md-form form-group">
                                    <label for="email">Email</label>
                                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  name="email"  value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Enter your email" autofocus>
                                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-10 mb-3 col-3 mx-auto">
                                <div class="md-form form-group">
                                    <label for="password">Password</label>
                                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="123456789" required autocomplete="current-password" >
                                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                       
                        <div class="form-group row">
                            <div class="col-md-10 col-3 mx-auto">
                                <button type="submit" class="btn btn-primary btn-block">
                                    Login
                                </button>
                            </div>
                        </div> 
                        <div id ="gmailDiv" class="col-md-10 col-3 mx-auto">
                            <a href="<?php echo e(url('auth/google')); ?>" class="btn btn-lg btn-default btn-block">
                                <img id ="gmail" src="http://localhost:8000/img/google_logo.png" alt="">
                                <strong>Login With Google</strong>
                            </a> 
                        </div>
                        <div class="form-group row">
                            <div class="col-md-10 col-3 mx-auto"> 
                                <div class="form-check">    
                                    <div class="left">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember"  value = "<?php echo e(old('remember') ? 'checked' : ''); ?>">
                                        <label class="form-check-label" for="remember">
                                            Remember Me
                                        </label>
                                    </div>
                                </div>
                                <div class="right">
                                    <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link" href="/forget-password">
                                            Forgot Your Password ?
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>      
            </div>
        </div>
    </div> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DatawordsPH\Desktop\BBO\BBOHRSystem\resources\views/auth/login.blade.php ENDPATH**/ ?>